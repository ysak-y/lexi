from setuptools import setup

setup(name='lexi',
version='0.1',
description='Easy development tool for Lex',
url='https://github.com/ysak-y/lexi-test.git',
author='Yoshiaki Yamada',
author_email='yoshiaki.0614@gmail.com',
license='MIT',
packages=['lexi'],
zip_safe=False)

