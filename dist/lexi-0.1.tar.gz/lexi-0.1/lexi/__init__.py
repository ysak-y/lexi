from . import alexa_io

alexa = alexa_io.Request()
